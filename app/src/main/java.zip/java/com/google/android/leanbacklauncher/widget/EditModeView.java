package com.google.android.leanbacklauncher.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.google.android.leanbacklauncher.ActiveItemsRowView;
import com.google.android.leanbacklauncher.animation.EditModeUninstallAnimationHolder;
import com.google.android.leanbacklauncher.animation.EditModeUninstallAnimationHolder.EditModeUninstallState;
import com.google.android.leanbacklauncher.animation.ViewFocusAnimator;
import com.google.android.leanbacklauncher.apps.BannerSelectedChangedListener;
import com.google.android.leanbacklauncher.apps.BannerView;
import com.google.android.leanbacklauncher.apps.OnEditModeChangedListener;
import com.google.android.leanbacklauncher.graphics.ClipCircleDrawable;
import com.google.android.leanbacklauncher.util.Util;
import java.util.ArrayList;

public final class EditModeView extends RelativeLayout implements OnEditModeChangedListener, BannerSelectedChangedListener, OnClickListener {
    private final ArrayList<EditModeViewActionListener> mActionListeners;
    private BannerView mCurSelectedBanner;
    private Button mFinishButton;
    private ViewFocusAnimator mFocusAnimator;
    private EditModeUninstallAnimationHolder mUninstallAnimation;
    private ImageView mUninstallApp;
    private ImageView mUninstallCircle;
    private ImageView mUninstallIcon;
    private ImageView mUninstallIconCircle;
    private OnEditModeUninstallPressedListener mUninstallListener;
    private TextView mUninstallText;

    public interface OnEditModeUninstallPressedListener {
        void onUninstallPressed(String str);
    }

    public EditModeView(Context context) {
        this(context, null);
    }

    public EditModeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EditModeView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mActionListeners = new ArrayList();
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mUninstallCircle = (ImageView) findViewById(2131624122);
        this.mUninstallIconCircle = (ImageView) findViewById(2131624123);
        this.mUninstallIcon = (ImageView) findViewById(2131624125);
        this.mUninstallText = (TextView) findViewById(2131624124);
        this.mFinishButton = (Button) findViewById(2131624126);
        this.mUninstallApp = (ImageView) findViewById(2131624121);
        this.mFocusAnimator = new ViewFocusAnimator(this.mUninstallApp);
        this.mFocusAnimator.setFocusImmediate(true);
        float zDeltaIcon = (float) getResources().getDimensionPixelOffset(2131558785);
        this.mUninstallApp.setZ((float) getResources().getDimensionPixelOffset(2131558784));
        this.mUninstallIconCircle.setZ(zDeltaIcon);
        this.mUninstallIcon.setZ(zDeltaIcon);
        this.mUninstallApp.setClipToOutline(true);
        this.mFinishButton.setOnClickListener(this);
        this.mUninstallText.setImportantForAccessibility(2);
        setUninstallCircleLayout();
        setUninstallIconCircleLayout();
        setUninstallTextLayout();
        this.mUninstallAnimation = new EditModeUninstallAnimationHolder(this);
    }

    public void onEditModeChanged(boolean editMode) {
        float f;
        int i = 0;
        if (!editMode) {
            setBannerUninstallMode(false);
            if (hasFocus()) {
                notifyOnExitEditModeTriggered();
            }
        }
        if (!editMode) {
            i = 8;
        }
        setVisibility(i);
        if (editMode) {
            f = 1.0f;
        } else {
            f = 0.0f;
        }
        setAlpha(f);
    }

    public void onSelectedChanged(BannerView v, boolean selected) {
        int i;
        int i2 = 8;
        if (selected) {
            this.mCurSelectedBanner = v;
        } else {
            this.mCurSelectedBanner = null;
        }
        ImageView imageView = this.mUninstallIconCircle;
        if (selected) {
            i = 0;
        } else {
            i = 8;
        }
        imageView.setVisibility(i);
        TextView textView = this.mUninstallText;
        if (selected) {
            i = 0;
        } else {
            i = 8;
        }
        textView.setVisibility(i);
        imageView = this.mUninstallIcon;
        if (selected) {
            i = 0;
        } else {
            i = 8;
        }
        imageView.setVisibility(i);
        imageView = this.mUninstallCircle;
        if (selected) {
            i = 0;
        } else {
            i = 8;
        }
        imageView.setVisibility(i);
        Button button = this.mFinishButton;
        if (!selected) {
            i2 = 0;
        }
        button.setVisibility(i2);
    }

    public void clearUninstallAndFinishLayers() {
        this.mUninstallIconCircle.setVisibility(8);
        this.mUninstallText.setVisibility(8);
        this.mUninstallIcon.setVisibility(8);
        this.mUninstallCircle.setVisibility(8);
        this.mFinishButton.setVisibility(8);
    }

    public void addActionListener(EditModeViewActionListener listener) {
        this.mActionListeners.add(listener);
    }

    public void removeActionListener(EditModeViewActionListener listener) {
        this.mActionListeners.remove(listener);
    }

    public void requestUninstallIconFocus(BannerView curView, ActiveItemsRowView activeItems) {
        this.mUninstallIcon.requestFocus();
        setBannerUninstallModeWithAnimation(true, curView, activeItems);
    }

    public void setBannerUninstallMode(boolean uninstallMode) {
        int i;
        this.mUninstallAnimation.setViewsToExitState();
        setUninstallCircleLayout();
        setUninstallIconCircleLayout();
        setUninstallTextLayout();
        ImageView imageView = this.mUninstallApp;
        if (uninstallMode) {
            i = 0;
        } else {
            i = 8;
        }
        imageView.setVisibility(i);
    }

    public void setBannerUninstallModeWithAnimation(boolean uninstallMode, BannerView curView, ActiveItemsRowView activeItems) {
        if (uninstallMode) {
            this.mUninstallAnimation.startAnimation(EditModeUninstallState.ENTER, curView, activeItems);
        } else {
            this.mUninstallAnimation.startAnimation(EditModeUninstallState.EXIT, curView, activeItems);
        }
    }

    public void uninstallComplete() {
        setBannerUninstallMode(false);
        notifyUninstallComplete();
    }

    public void uninstallFailure() {
        setBannerUninstallMode(false);
        notifyUninstallFailure();
    }

    public void setBannerDrawable(Drawable drawable) {
        this.mUninstallApp.setImageDrawable(drawable);
    }

    public void setUninstallListener(OnEditModeUninstallPressedListener listener) {
        this.mUninstallListener = listener;
    }

    public Button getFinishButton() {
        return this.mFinishButton;
    }

    public ImageView getUninstallIcon() {
        return this.mUninstallIcon;
    }

    public ImageView getUninstallCircle() {
        return this.mUninstallCircle;
    }

    public ImageView getUninstallApp() {
        return this.mUninstallApp;
    }

    public TextView getUninstallText() {
        return this.mUninstallText;
    }

    public ImageView getUninstallIconCircle() {
        return this.mUninstallIconCircle;
    }

    private void notifyOnExitEditModeTriggered() {
        for (EditModeViewActionListener listener : this.mActionListeners) {
            listener.onEditModeExitTriggered();
        }
    }

    private void notifyOnFocusLeavingEditMode(int from) {
        for (EditModeViewActionListener listener : this.mActionListeners) {
            listener.onFocusLeavingEditModeLayer(from);
        }
    }

    private void notifyUninstallComplete() {
        for (EditModeViewActionListener listener : this.mActionListeners) {
            listener.onUninstallComplete();
        }
    }

    private void notifyUninstallFailure() {
        for (EditModeViewActionListener listener : this.mActionListeners) {
            listener.onUninstallFailure();
        }
    }

    private String notifyPrepForUninstall() {
        String packageUninstalling = "";
        for (EditModeViewActionListener listener : this.mActionListeners) {
            String result = listener.onPrepForUninstall();
            if (!(result == null || result.isEmpty())) {
                packageUninstalling = result;
            }
        }
        return packageUninstalling;
    }

    public void onBackPressed() {
        if (this.mCurSelectedBanner != null) {
            this.mCurSelectedBanner.notifyEditModeManager(false);
            this.mCurSelectedBanner.setSelected(false);
            return;
        }
        notifyOnExitEditModeTriggered();
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        if (action == 0) {
            if (keyCode == 19 && this.mFinishButton.isFocused()) {
                notifyOnFocusLeavingEditMode(0);
            } else if ((keyCode == 19 && this.mUninstallIcon.isFocused()) || (keyCode == 4 && this.mUninstallIcon.isFocused())) {
                notifyOnFocusLeavingEditMode(1);
            } else if ((Util.isConfirmKey(keyCode) || keyCode == 4) && this.mFinishButton.isFocused()) {
                notifyOnExitEditModeTriggered();
            } else if (Util.isConfirmKey(keyCode) && this.mUninstallIcon.isFocused()) {
                this.mUninstallListener.onUninstallPressed(notifyPrepForUninstall());
            }
            return true;
        } else if (action == 1) {
            return true;
        } else {
            return super.dispatchKeyEvent(event);
        }
    }

    private void setUninstallCircleLayout() {
        LayoutParams circlelp = new LayoutParams(getResources().getDimensionPixelSize(2131558779), getResources().getDimensionPixelOffset(2131558780));
        circlelp.addRule(12);
        circlelp.addRule(13);
        this.mUninstallCircle.setImageDrawable(new ClipCircleDrawable(getResources().getColor(2131361961)));
        this.mUninstallCircle.setLayoutParams(circlelp);
    }

    private void setUninstallIconCircleLayout() {
        LayoutParams iconCirclelp = new LayoutParams(getResources().getDimensionPixelSize(2131558783), getResources().getDimensionPixelSize(2131558783));
        iconCirclelp.setMargins(0, 0, 0, getResources().getDimensionPixelSize(2131558776));
        iconCirclelp.addRule(2, 2131624124);
        iconCirclelp.addRule(13);
        this.mUninstallIconCircle.setImageDrawable(new ClipCircleDrawable(getResources().getColor(2131361962)));
        this.mUninstallIconCircle.setLayoutParams(iconCirclelp);
    }

    private void setUninstallTextLayout() {
        LayoutParams textlp = new LayoutParams(-2, -2);
        textlp.setMargins(0, 0, 0, getResources().getDimensionPixelOffset(2131558777));
        textlp.addRule(14);
        textlp.addRule(12);
        this.mUninstallText.setLayoutParams(textlp);
    }

    public void onClick(View v) {
        if (v == this.mFinishButton) {
            notifyOnExitEditModeTriggered();
        }
    }
}
