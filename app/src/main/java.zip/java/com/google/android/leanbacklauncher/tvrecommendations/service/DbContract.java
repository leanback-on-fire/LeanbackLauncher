package com.google.android.leanbacklauncher.tvrecommendations.service;

public class DbContract {
    private DbContract() {
    }
}
