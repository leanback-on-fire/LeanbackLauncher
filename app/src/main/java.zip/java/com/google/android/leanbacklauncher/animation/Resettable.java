package com.google.android.leanbacklauncher.animation;

public interface Resettable {
    void reset();
}
