package com.google.android.leanbacklauncher.animation;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.leanbacklauncher.animation.MassSlideAnimator.Direction;
import com.google.android.leanbacklauncher.notifications.HomeScreenView;
import com.google.android.leanbacklauncher.notifications.NotificationCardView;

public class LauncherReturnAnimator extends ForwardingAnimatorSet {
    public LauncherReturnAnimator(ViewGroup root, Rect epicenter, View[] headers, HomeScreenView homeScreenView) {
        Builder builder;
        Resources res = root.getResources();
        int fadeDuration = res.getInteger(2131427401);
        int fadeDelay = res.getInteger(2131427402);
        if (root.findFocus() instanceof NotificationCardView) {
            builder = ((AnimatorSet) this.mDelegate).play(new MassSlideAnimator.Builder(root).setEpicenter(epicenter).setDirection(Direction.SLIDE_IN).setExclude(NotificationCardView.class).setFade(false).build());
            builder.with(new MassFadeAnimator.Builder(root).setDirection(MassFadeAnimator.Direction.FADE_IN).setTarget(NotificationCardView.class).setDuration((long) res.getInteger(2131427407)).build());
        } else {
            builder = ((AnimatorSet) this.mDelegate).play(new MassSlideAnimator.Builder(root).setEpicenter(epicenter).setDirection(Direction.SLIDE_IN).setFade(false).build());
            if (!(homeScreenView == null || homeScreenView.isRowViewVisible())) {
                Animator anim = new FadeAnimator(homeScreenView, FadeAnimator.Direction.FADE_IN);
                anim.setDuration((long) fadeDuration);
                anim.setStartDelay((long) fadeDelay);
                builder.with(anim);
            }
        }
        for (View header : headers) {
            FadeAnimator anim = new FadeAnimator(header, FadeAnimator.Direction.FADE_IN);
            anim.setDuration((long) fadeDuration);
            anim.setStartDelay((long) fadeDelay);
            builder.with(anim);
        }
    }
}
