package com.google.android.leanbacklauncher.recline.util;

public interface PostProc<T> {
    T postProcess(T t);
}
