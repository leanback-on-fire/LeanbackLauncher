package com.google.android.leanbacklauncher.notifications;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.preference.R.styleable;
import android.util.AttributeSet;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class HomeScreenView extends ViewFlipper {
    private TextView mErrorMessageText;
    private final String mErrorNoConnection;
    private final String mErrorNoRecs;
    private final String mErrorRecsDisabled;
    private HomeScreenMessaging mHomeScreenMessaging;
    private NotificationRowView mRow;

    public void flipToView(int view) {
        switch (view) {
            case android.support.v7.preference.R.styleable.Preference_android_icon /*0*/:
                super.setDisplayedChild(0);
            case android.support.v7.recyclerview.R.styleable.RecyclerView_android_descendantFocusability /*1*/:
                super.setDisplayedChild(2);
            case android.support.v7.recyclerview.R.styleable.RecyclerView_layoutManager /*2*/:
                super.setDisplayedChild(3);
                this.mErrorMessageText.setText(this.mErrorRecsDisabled);
            case android.support.v7.preference.R.styleable.Preference_android_layout /*3*/:
                super.setDisplayedChild(3);
                this.mErrorMessageText.setText(this.mErrorNoRecs);
            case android.support.v7.preference.R.styleable.Preference_android_title /*4*/:
                super.setDisplayedChild(3);
                this.mErrorMessageText.setText(this.mErrorNoConnection);
            default:
        }
    }

    public HomeScreenMessaging getHomeScreenMessaging() {
        return this.mHomeScreenMessaging;
    }

    public HomeScreenView(Context context, AttributeSet attrs) {
        super(context, attrs);
        Resources res = context.getResources();
        this.mErrorRecsDisabled = res.getString(2131296415);
        this.mErrorNoRecs = res.getString(2131296416);
        this.mErrorNoConnection = res.getString(2131296417);
        this.mHomeScreenMessaging = new HomeScreenMessaging(this);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mErrorMessageText = (TextView) findViewById(2131624285);
        this.mRow = (NotificationRowView) getChildAt(0);
    }

    public NotificationRowView getNotificationRow() {
        return this.mRow;
    }

    public boolean isRowViewVisible() {
        return getDisplayedChild() == 0;
    }
}
