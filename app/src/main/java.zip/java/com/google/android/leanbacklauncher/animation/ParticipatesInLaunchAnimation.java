package com.google.android.leanbacklauncher.animation;

public interface ParticipatesInLaunchAnimation {
}
