package com.google.android.leanbacklauncher.recommendations;

import com.google.android.leanbacklauncher.tvrecommendations.service.BaseNotificationsService;

public class NotificationsService extends BaseNotificationsService {
    public NotificationsService() {
        super(false);
    }
}
