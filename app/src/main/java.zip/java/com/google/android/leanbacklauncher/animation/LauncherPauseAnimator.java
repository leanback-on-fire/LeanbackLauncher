package com.google.android.leanbacklauncher.animation;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.content.res.Resources;
import android.view.ViewGroup;
import com.google.android.leanbacklauncher.animation.FadeAnimator.Direction;

public final class LauncherPauseAnimator extends ForwardingAnimatorSet {
    public LauncherPauseAnimator(ViewGroup root) {
        Resources res = root.getResources();
        Animator anim = new FadeAnimator(root, Direction.FADE_OUT);
        anim.setDuration((long) res.getInteger(2131427408));
        ((AnimatorSet) this.mDelegate).play(anim);
    }
}
