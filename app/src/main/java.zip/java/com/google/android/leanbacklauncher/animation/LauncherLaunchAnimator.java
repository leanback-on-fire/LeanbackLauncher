package com.google.android.leanbacklauncher.animation;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.google.android.leanbacklauncher.animation.FadeAnimator.Direction;
import com.google.android.leanbacklauncher.notifications.HomeScreenView;

public final class LauncherLaunchAnimator extends ForwardingAnimatorSet {
    public LauncherLaunchAnimator(ViewGroup root, View cause, Rect epicenter, ImageView circleLayerView, int color, View[] headers, HomeScreenView homeScreenView) {
        Resources res = root.getResources();
        int fadeDuration = res.getInteger(2131427403);
        int fadeDelay = res.getInteger(2131427404);
        Animator anim = new CircleTakeoverAnimator(cause, circleLayerView, color);
        anim.setDuration((long) res.getInteger(2131427400));
        Builder builder = ((AnimatorSet) this.mDelegate).play(anim);
        anim = new FadeAnimator(cause, Direction.FADE_OUT);
        anim.setDuration((long) res.getInteger(2131427405));
        anim.setStartDelay((long) res.getInteger(2131427406));
        builder.with(anim);
        builder.with(new MassSlideAnimator.Builder(root).setEpicenter(epicenter).setExclude(cause).setFade(false).build());
        if (!(homeScreenView == null || homeScreenView.isRowViewVisible())) {
            anim = new FadeAnimator(homeScreenView, Direction.FADE_OUT);
            anim.setDuration((long) fadeDuration);
            anim.setStartDelay((long) fadeDelay);
            builder.with(anim);
        }
        for (View header : headers) {
            anim = new FadeAnimator(header, Direction.FADE_OUT);
            anim.setDuration((long) fadeDuration);
            anim.setStartDelay((long) fadeDelay);
            builder.with(anim);
        }
    }
}
