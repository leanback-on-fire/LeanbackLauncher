package com.google.android.leanbacklauncher.wallpaper;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v17.leanback.graphics.ColorFilterCache;
import android.support.v17.leanback.graphics.ColorFilterDimmer;
import android.support.v4.content.ContextCompat;
import android.support.v7.recyclerview.R.styleable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import com.google.android.leanbacklauncher.HomeScrollManager.HomeScrollFractionListener;
import com.google.android.leanbacklauncher.MainActivity;
import com.google.android.leanbacklauncher.animation.AnimatorLifecycle.OnAnimationFinishedListener;
import com.google.android.leanbacklauncher.util.Partner;
import com.google.android.leanbacklauncher.util.Util;
import com.google.android.leanbacklauncher.wallpaper.AnimatedLayer.AnimationListener;
import com.google.android.leanbacklauncher.recline.util.BitmapWorkerOptions;
import com.google.android.leanbacklauncher.recline.util.BitmapWorkerOptions.Builder;
import com.google.android.leanbacklauncher.recline.util.DrawableDownloader;
import com.google.android.leanbacklauncher.recline.util.DrawableDownloader.BitmapCallback;
import com.google.android.leanbacklauncher.recline.util.RefcountBitmapDrawable;

public class LauncherWallpaper extends FrameLayout implements AnimationListener, OnAnimationFinishedListener, HomeScrollFractionListener {
    private WallpaperImage mBackground;
    private ColorDrawable mBackgroundColor;
    private int mBackgroundDim;
    private final BitmapCallback mBitmapDownloadCallback;
    private final DrawableDownloader mBitmapDownloader;
    private String mCurrentBackgroundUri;
    private ColorFilterDimmer mDimmer;
    private String mDownloadingUri;
    private AnimatedLayer mFadeMaskExt;
    private Handler mHandler;
    private boolean mInShyMode;
    private AnimatedLayer mOverlay;
    private boolean mPendingChange;
    private Drawable mPendingImage;
    private String mPendingImgUri;
    private final float mScrollDarkeningAmount;
    private final float mScrollDarkeningOffset;
    private int mScrollPosition;
    private FadeMaskView mVideoFadeMask;
    private ImageView mVideoFadeMaskExt;
    private WallpaperImage mWallpaper;
    private final int mWallpaperDelay;
    private final int mWallpaperFetchTimeout;
    private final WallpaperInstaller mWallpaperInstaller;
    private final WallpaperManager mWallpaperManager;
    private boolean mWallpaperReady;
    private final float mWallpaperScrollScale;
    private final float mZoom;
    private final float mZoomThreshold;

    /* renamed from: com.google.android.leanbacklauncher.wallpaper.LauncherWallpaper.1 */
    class C02051 extends Handler {
        C02051() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case android.support.v7.recyclerview.R.styleable.RecyclerView_android_descendantFocusability /*1*/:
                    LauncherWallpaper.this.setBackgroundImage((String) msg.obj);
                case android.support.v7.recyclerview.R.styleable.RecyclerView_layoutManager /*2*/:
                    PendingUpdateData args = (PendingUpdateData) msg.obj;
                    LauncherWallpaper.this.setOverlayBackground(args.image, args.uri);
                case android.support.v7.preference.R.styleable.Preference_android_layout /*3*/:
                    LauncherWallpaper.this.mBitmapDownloader.cancelDownload(LauncherWallpaper.this.mBitmapDownloadCallback);
                    Log.w("LauncherWallpaper", "TIMEOUT fetching wallpeper image: " + LauncherWallpaper.this.mDownloadingUri);
                    LauncherWallpaper.this.mDownloadingUri = null;
                    LauncherWallpaper.this.setOverlayBackground(null, null);
                default:
            }
        }
    }

    /* renamed from: com.google.android.leanbacklauncher.wallpaper.LauncherWallpaper.2 */
    class C02062 extends BitmapCallback {
        C02062() {
        }

        public void onCompleted(Drawable bitmap) {
            LauncherWallpaper.this.mHandler.removeMessages(3);
            if (bitmap == null) {
                LauncherWallpaper.this.setOverlayBackground(null, null);
            } else {
                LauncherWallpaper.this.setOverlayBackground(bitmap, LauncherWallpaper.this.mDownloadingUri);
            }
            LauncherWallpaper.this.releaseDrawable(bitmap);
            LauncherWallpaper.this.mDownloadingUri = null;
        }
    }

    private static class PendingUpdateData {
        public Drawable image;
        public String uri;

        private PendingUpdateData() {
        }
    }

    public LauncherWallpaper(Context context) {
        this(context, null);
    }

    public LauncherWallpaper(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LauncherWallpaper(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mInShyMode = true;
        this.mPendingChange = false;
        this.mHandler = new C02051();
        this.mBitmapDownloadCallback = new C02062();
        this.mBitmapDownloader = DrawableDownloader.getInstance(context);
        this.mWallpaperManager = WallpaperManager.getInstance(context);
        this.mWallpaperInstaller = WallpaperInstaller.getInstance(context);
        this.mScrollDarkeningOffset = (float) getContext().getResources().getDimensionPixelOffset(2131558850);
        TypedValue out = new TypedValue();
        getResources().getValue(2131165206, out, true);
        this.mScrollDarkeningAmount = out.getFloat();
        getResources().getValue(2131165205, out, true);
        this.mWallpaperScrollScale = out.getFloat();
        getResources().getValue(2131165207, out, true);
        this.mZoom = out.getFloat();
        getResources().getValue(2131165208, out, true);
        this.mZoomThreshold = this.mScrollDarkeningOffset / out.getFloat();
        int backgroundColor = ContextCompat.getColor(context, 2131361959);
        this.mBackgroundColor = new ColorDrawable(backgroundColor);
        this.mDimmer = ColorFilterDimmer.create(ColorFilterCache.getColorFilterCache(backgroundColor), 0.0f, this.mScrollDarkeningAmount);
        this.mWallpaperDelay = getResources().getInteger(2131427382);
        this.mWallpaperFetchTimeout = getResources().getInteger(2131427383);
        Bitmap maskBitmap = Partner.get(context).getSystemBackgroundMask();
        if (maskBitmap == null) {
            maskBitmap = BitmapFactory.decodeResource(getResources(), 2130837582);
        }
        DisplayMetrics metrics = Util.getDisplayMetrics(context);
        this.mBitmapDownloader.registerPostProc(2130837582, new BackgroundImagePostProcessor(context.getResources(), maskBitmap, metrics.widthPixels, metrics.heightPixels));
    }

    public void resetBackground() {
        this.mHandler.removeCallbacksAndMessages(null);
        this.mOverlay.cancelAnimation();
        this.mOverlay.setVisibility(8);
        this.mFadeMaskExt.cancelAnimation();
        this.mOverlay.setImageDrawable(null);
        this.mBackground.setImageDrawable(null);
        this.mCurrentBackgroundUri = null;
        updateChildVisibility();
        updateScrollPosition();
    }

    public boolean getShynessMode() {
        return this.mInShyMode;
    }

    public void setShynessMode(boolean shyMode) {
        this.mInShyMode = shyMode;
        updateChildVisibility();
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, null));
    }

    public void setOverlayBackground(Drawable drawable, String uri) {
        MainActivity activity = (MainActivity) getContext();
        if (this.mOverlay.isAnimating() || activity.isLaunchAnimationInProgress()) {
            releaseDrawable(this.mPendingImage);
            this.mPendingChange = true;
            this.mPendingImage = addRef(drawable);
            this.mPendingImgUri = uri;
        } else if (drawable != null) {
            this.mCurrentBackgroundUri = uri;
            this.mOverlay.animateIn(drawable);
            this.mFadeMaskExt.animateIn(this.mBackgroundColor);
        } else {
            this.mCurrentBackgroundUri = null;
            this.mOverlay.animateOut(this.mBackground.getDrawable());
            this.mBackground.setVisibility(8);
            this.mFadeMaskExt.animateOut(this.mBackgroundColor);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mWallpaper = (WallpaperImage) findViewById(2131624306);
        this.mBackground = (WallpaperImage) findViewById(2131624307);
        this.mOverlay = (AnimatedLayer) findViewById(2131624308);
        this.mFadeMaskExt = (AnimatedLayer) findViewById(2131624309);
        this.mVideoFadeMask = (FadeMaskView) findViewById(2131624310);
        this.mVideoFadeMaskExt = (ImageView) findViewById(2131624311);
        if (this.mVideoFadeMask != null) {
            Bitmap videoMask = Partner.get(getContext()).getSystemBackgroundVideoMask();
            if (videoMask == null) {
                videoMask = BitmapFactory.decodeResource(getResources(), 2130837583);
            }
            this.mVideoFadeMask.setBitmap(videoMask);
        }
        this.mOverlay.setAnimationListener(this);
        ((MainActivity) getContext()).setOnLaunchAnimationFinishedListener(this);
    }

    public void onBackgroundImageChanged(String imageUri, boolean notifActive) {
        if (!this.mInShyMode) {
            return;
        }
        if (imageUri == null || !(TextUtils.equals(imageUri, this.mPendingImgUri) || TextUtils.equals(imageUri, this.mDownloadingUri))) {
            this.mHandler.removeCallbacksAndMessages(null);
            cancelPendingUpdate();
            this.mBitmapDownloader.cancelDownload(this.mBitmapDownloadCallback);
            this.mDownloadingUri = null;
            if (!TextUtils.equals(imageUri, this.mCurrentBackgroundUri)) {
                if (notifActive || imageUri != null) {
                    this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, imageUri), (long) this.mWallpaperDelay);
                }
            }
        }
    }

    private void cancelPendingUpdate() {
        if (this.mPendingChange) {
            this.mPendingChange = false;
            releaseDrawable(this.mPendingImage);
            this.mPendingImage = null;
        }
        this.mPendingImgUri = null;
    }

    private void setBackgroundImage(String imageUri) {
        this.mBitmapDownloader.cancelDownload(this.mBitmapDownloadCallback);
        this.mDownloadingUri = null;
        if (imageUri != null) {
            fetchWallpaperImage(imageUri);
        } else {
            setOverlayBackground(null, null);
        }
    }

    private void fetchWallpaperImage(String uri) {
        this.mHandler.removeMessages(3);
        BitmapWorkerOptions options = new Builder(getContext().getApplicationContext()).resource(Uri.parse(uri)).cacheFlag(1).postProcId(2130837582).width(1920).height(1080).build();
        this.mDownloadingUri = uri;
        this.mBitmapDownloader.getBitmap(options, this.mBitmapDownloadCallback);
        this.mHandler.sendEmptyMessageDelayed(3, (long) this.mWallpaperFetchTimeout);
    }

    private void releaseDrawable(Drawable drawable) {
        if (drawable instanceof RefcountBitmapDrawable) {
            int releaseRef = ((RefcountBitmapDrawable) drawable).getRefcountObject().releaseRef();
        }
    }

    private Drawable addRef(Drawable drawable) {
        if (drawable instanceof RefcountBitmapDrawable) {
            ((RefcountBitmapDrawable) drawable).getRefcountObject().addRef();
        }
        return drawable;
    }

    public void onAnimationFinished() {
        applyPendingUpdateIfNecessary();
    }

    public void animationDone(boolean visible) {
        if (visible) {
            this.mBackground.setImageDrawable(this.mOverlay.getDrawable());
            this.mOverlay.setVisibility(8);
        } else {
            this.mOverlay.setImageDrawable(null);
        }
        updateChildVisibility();
        applyPendingUpdateIfNecessary();
    }

    private void applyPendingUpdateIfNecessary() {
        if (this.mPendingChange) {
            PendingUpdateData args = new PendingUpdateData();
            args.image = this.mPendingImage;
            args.uri = this.mPendingImgUri;
            this.mHandler.sendMessage(this.mHandler.obtainMessage(2, args));
            this.mPendingImage = null;
            this.mPendingChange = false;
            this.mPendingImgUri = null;
        }
    }

    public void onScrollPositionChanged(int position, float fractionFromTop) {
        this.mScrollPosition = position;
        updateScrollPosition();
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            updateScrollPosition();
        }
    }

    private void updateScrollPosition() {
        loadWallpaperIfNeeded();
        int newPos = Math.round(((float) this.mScrollPosition) / this.mWallpaperScrollScale);
        this.mBackground.setY((float) newPos);
        this.mOverlay.setY((float) newPos);
        this.mVideoFadeMask.setY((float) newPos);
        if (this.mWallpaper != null) {
            this.mWallpaper.setY((float) newPos);
        }
        int maskExtY = getMeasuredHeight() + newPos;
        this.mFadeMaskExt.setY((float) maskExtY);
        this.mVideoFadeMaskExt.setY((float) maskExtY);
        float dimLevel = (1.0f - Math.min(1.0f, ((float) Math.abs(this.mScrollPosition)) / this.mScrollDarkeningOffset)) * this.mScrollDarkeningAmount;
        float zoomLevel = this.mZoom * (1.0f - Math.min(1.0f, ((float) Math.abs(this.mScrollPosition)) / this.mZoomThreshold));
        this.mBackground.setZoomLevel(zoomLevel);
        this.mOverlay.setZoomLevel(zoomLevel);
        this.mDimmer.setActiveLevel(dimLevel);
        this.mBackground.setColorFilter(this.mDimmer.getColorFilter());
        this.mBackgroundDim = Color.argb((int) ((this.mScrollDarkeningAmount * 255.0f) * (1.0f - dimLevel)), 0, 0, 0);
        this.mOverlay.setColorFilter(this.mDimmer.getColorFilter());
        invalidate();
    }

    private void updateChildVisibility() {
        if (this.mInShyMode) {
            this.mVideoFadeMask.setVisibility(8);
            this.mVideoFadeMaskExt.setVisibility(8);
            if (this.mCurrentBackgroundUri != null) {
                this.mBackground.setVisibility(0);
                this.mFadeMaskExt.setVisibility(0);
            } else {
                this.mBackground.setVisibility(8);
                this.mFadeMaskExt.setVisibility(8);
            }
            if (this.mWallpaper != null) {
                this.mWallpaper.setVisibility(0);
                return;
            }
            return;
        }
        this.mVideoFadeMask.setVisibility(0);
        this.mVideoFadeMaskExt.setVisibility(0);
        this.mBackground.setVisibility(8);
        this.mFadeMaskExt.setVisibility(0);
        if (this.mWallpaper != null) {
            this.mWallpaper.setVisibility(8);
        }
    }

    private void loadWallpaperIfNeeded() {
        if (!this.mWallpaperReady && this.mInShyMode) {
            Bitmap bitmap = this.mWallpaperInstaller.getWallpaperBitmap();
            this.mWallpaper.setImageBitmap(bitmap);
            this.mWallpaper.setLayoutParams(new LayoutParams(-1, bitmap.getHeight()));
            this.mWallpaperReady = true;
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        if (this.mInShyMode) {
            canvas.drawColor(this.mBackgroundDim, Mode.SRC);
        }
        super.dispatchDraw(canvas);
    }
}
