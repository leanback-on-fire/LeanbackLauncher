package com.google.android.leanbacklauncher.apps;

public interface OnEditModeChangedListener {
    void onEditModeChanged(boolean z);
}
