package com.google.android.leanbacklauncher.animation;

public interface ParticipatesInScrollAnimation {
    void setAnimationsEnabled(boolean z);
}
