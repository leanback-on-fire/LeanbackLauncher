package com.google.android.leanbacklauncher.apps;

public interface BannerSelectedChangedListener {
    void onSelectedChanged(BannerView bannerView, boolean z);
}
