package com.google.android.leanbacklauncher;

import com.google.android.leanbacklauncher.animation.ViewDimmer.DimState;

public interface DimmableItem {
    void setDimState(DimState dimState, boolean z);
}
