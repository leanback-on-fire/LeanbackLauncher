package com.google.android.leanbacklauncher;

import android.app.Application;

public class LauncherApplication extends Application {
}
