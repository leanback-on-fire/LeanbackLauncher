package com.google.android.leanbacklauncher.animation;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.google.android.leanbacklauncher.animation.MassFadeAnimator.Direction;
import com.google.android.leanbacklauncher.notifications.HomeScreenView;
import com.google.android.leanbacklauncher.notifications.NotificationCardView;

public final class NotificationLaunchAnimator extends ForwardingAnimatorSet {
    public NotificationLaunchAnimator(ViewGroup root, NotificationCardView cause, Rect epicenter, ImageView circleLayerView, int color, View[] headers, HomeScreenView homeScreenView) {
        Resources res = root.getResources();
        int fadeDuration = res.getInteger(2131427403);
        int fadeDelay = res.getInteger(2131427404);
        Animator anim = new CircleTakeoverAnimator(cause, circleLayerView, color);
        anim.setDuration((long) res.getInteger(2131427400));
        Builder builder = ((AnimatorSet) this.mDelegate).play(anim);
        builder.with(new MassFadeAnimator.Builder(root).setDirection(Direction.FADE_OUT).setTarget(NotificationCardView.class).setDuration((long) res.getInteger(2131427407)).build());
        builder.with(new MassSlideAnimator.Builder(root).setEpicenter(epicenter).setExclude((View) cause).setExclude(NotificationCardView.class).setFade(false).build());
        for (View fadeAnimator : headers) {
            anim = new FadeAnimator(fadeAnimator, FadeAnimator.Direction.FADE_OUT);
            anim.setDuration((long) fadeDuration);
            anim.setStartDelay((long) fadeDelay);
            builder.with(anim);
        }
    }
}
